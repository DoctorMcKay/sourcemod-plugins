<div id="footer">Powered by <a href="https://forums.alliedmods.net/showthread.php?t=172258">SourceMod DJ</a> v<?php echo SMDJ_VERSION; ?></div>
</body>
</html>